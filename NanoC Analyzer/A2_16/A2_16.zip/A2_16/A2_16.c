int yylex(void);

int main(){
    yylex();
}